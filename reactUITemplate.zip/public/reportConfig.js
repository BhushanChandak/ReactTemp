var reportConfig = [
    {
        Basket:
        {
            reportId: "a29720f4-1037-4d49-a85b-cef4b0a6f69d",
            embedPageName: "ReportSectionc7cc429862d90228cca0",
            embedDashboardTable: "groceries",
            filterColumn: "Item"
        },
    }
];


function GetReportConfig() {
    var page = "Basket"; //window.location.pathname.split("/").pop();

    var embedConfig = reportConfig[0][page];

    return embedConfig;
}