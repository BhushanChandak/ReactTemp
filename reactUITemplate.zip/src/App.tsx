import React from 'react';
import 'antd/dist/antd.min.css'
import './App.css';
import LayoutComponent from './component/layout';

function App() {
  return (
    <div className="App">
      <LayoutComponent></LayoutComponent>
    </div>
  );
}

export default App;
