import React from 'react';
import ReactDOM from 'react-dom/client';
import { Provider } from "react-redux";
import "./index.css";
import { configStore } from "./store/config";
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import { BrowserRouter } from 'react-router-dom';
import ErrorBoundary from './component/error-boundaries';

const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);

const store = configStore();

root.render(
  <Provider store={store}>
    <ErrorBoundary>
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </ErrorBoundary>
  </Provider>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
