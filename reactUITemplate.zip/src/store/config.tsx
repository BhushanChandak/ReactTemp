import { createBrowserHistory } from "history";
import { configureStore, getDefaultMiddleware } from "@reduxjs/toolkit";
import createSagaMiddleware from "redux-saga";
import createRootReducer from "./rootReducer";
import rootSaga from "./rootSaga";

export const history = createBrowserHistory();

const sagaMiddleware = createSagaMiddleware();
const middleware = [...getDefaultMiddleware({ thunk: false }), sagaMiddleware];

export const configStore = () => {
  const store = configureStore({
    reducer: createRootReducer(history),
    middleware,
    devTools: true,
  });

  sagaMiddleware.run(rootSaga);
  return store;
};
