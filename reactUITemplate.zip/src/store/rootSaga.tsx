import { all } from "redux-saga/effects";
import powerBiSaga from "../containers/power-bi/sagas";
import usersSaga from "../containers/user/sagas";

export default function* rootSaga() {
  yield all([
    usersSaga(),
    powerBiSaga()
  ]);
}
