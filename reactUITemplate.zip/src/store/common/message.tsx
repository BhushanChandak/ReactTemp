
export const API_ERROR_MESSAGE = () => {
    const languageSelected = localStorage.getItem("language");
    let message = "";
    switch (languageSelected) {
        case "fr":
            message = "Erreur lors de l'obtention des données";
            break;
        default:
            message = "Error while getting data";
            break;
    }
    return message;
};

export const STRING_LIMIT_ERROR_MESSAGE = () => {
    const languageSelected = localStorage.getItem("language");
    let message = "";
    switch (languageSelected) {
        case "fr":
            message = "Le nom du niveau ne doit pas dépasser 100 caractères";
            break;
        default:
            message = "Level Name should be not more than 100 chars";
            break;
    }
    return message;
};

export const DATA_SAVE_SUCCESS = () => {
    const languageSelected = localStorage.getItem("language");
    let message = "";
    switch (languageSelected) {
        case "fr":
            message = "Données enregistrées avec succès";
            break;
        default:
            message = "Data saved successfully";
            break;
    }
    return message;
};

export const DATA_UPDATE_SUCCESS = () => {
    const languageSelected = localStorage.getItem("language");
    let message = "";
    switch (languageSelected) {
        case "fr":
            message = "Données mises à jour avec succès";
            break;
        default:
            message = "Data updated successfully";
            break;
    }
    return message;
};

export const DATA_DELETE_SUCCESS = () => {
    const languageSelected = localStorage.getItem("language");
    let message = "";
    switch (languageSelected) {
        case "fr":
            message = "Données supprimées avec succès";
            break;
        default:
            message = "Data deleted successfully";
            break;
    }
    return message;
};

export const NUMBERRANGEVALIDATION = () => {
    const languageSelected = localStorage.getItem("language");
    let message = "";
    switch (languageSelected) {
        case "fr":
            message = "Veuillez ajouter de la valeur entre 1 et 52";
            break;
        default:
            message = "Please add value between 1-52";
            break;
    }
    return message;
};

export const NUMBERRANGEVALIDATIONPOPULATIONDEMOGRAPHIC = () => {
    const languageSelected = localStorage.getItem("language");
    let message = "";
    switch (languageSelected) {
        case "fr":
            message = "Veuillez ajouter de la valeur entre 0 et 100";
            break;
        default:
            message = "Please add value between 0-100";
            break;
    }
    return message;
};

export const ENTITY_ASSOCIATED_MESSAGE = () => {
    const languageSelected = localStorage.getItem("language");
    let message = "";
    switch (languageSelected) {
        case "fr":
            message = "Vous ne pouvez pas supprimer cet élément car il est en cours d'utilisation.";
            break;
        default:
            message = "You cannot delete this item because it's in use.";
            break;
    }
    return message;
};

export const ENTITY_DUPLICATE_MESSAGE = () => {
    const languageSelected = localStorage.getItem("language");
    let message = "";
    switch (languageSelected) {
        case "fr":
            message = "Vous ne pouvez pas ajouter d'élément en double.";
            break;
        default:
            message = "You cannot add duplicate item.";
            break;
    }
    return message;
};

export const DUPLICATE_DESIGNATION_MESSAGE = () => {
    const languageSelected = localStorage.getItem("language");
    let message = "";
    switch (languageSelected) {
        case "fr":
            message = "La désignation saisie est déjà associée à un autre vaccin.";
            break;
        default:
            message = "The entered designation is already associated with other vaccine.";
            break;
    }
    return message;
};

export const ENTITY_APP_NOT_SYNCED = () => {
    const languageSelected = localStorage.getItem("language");
    let message = "";
    switch (languageSelected) {
        case "fr":
            message = "L'application de bureau n'est pas synchronisée. Veuillez le synchroniser, puis créer un magasin en ligne.";
            break;
        default:
            message = "Desktop app is not synced. Please sync it and then make store to online.";
            break;
    }
    return message;
};

export const CHARACTERVALIDATION = () => {
    const languageSelected = localStorage.getItem("language");
    let message = "";
    switch (languageSelected) {
        case "fr":
            message = "Vous ne pouvez saisir que des espaces, des traits de soulignement, des tirets et des caractères alphanumériques dans ce champ";
            break;
        default:
            message = "You can enter only space, underscore, hyphen and alphanumeric, characters in this field";
            break;
    }
    return message;
};
 
export const ASSOCIATED_STORE = (levelName: any) => {
    const languageSelected = localStorage.getItem("language");
    let message = "";
    switch (languageSelected) {

        case "fr":
            message = "Il y a des magasins associés à ce"+  levelName  + ". Veuillez supprimer les magasins avant de désactiver le niveau.";
            break;

        default:
            message = "There are store(s) associated to this " +  levelName  + " . Please delete the stores before deactivating the level.";
            break;
    }
    return message;
};

export const ENTITY_LEVEL_MORETHAN_FIVE = () => {
    const languageSelected = localStorage.getItem("language");
    let message = "";
    switch (languageSelected) {
        case "fr":
            message = "Le fichier d'importation ne doit pas contenir plus de niveau que le niveau actif.";
            break;
        default:
            message = "Import file must not contain level more than active level.";
            break;
    }
    return message;
};
export const TARGET_POPULATION_SHOULD_BE_INTEGER = () => {
    const languageSelected = localStorage.getItem("language");
    let message = "";
    switch (languageSelected) {
        case "fr":
            message = "Le champ Population cible dans le fichier d'importation doit être une valeur entière.";
            break;
        default:
            message = "Target Population field in import file should be interger value.";
            break;
    }
    return message;
};

export const STORE_NOT_PRESENT = () => {
    const languageSelected = localStorage.getItem("language");
    let message = "";
    switch (languageSelected) {
        case "fr":
            message = "Les données de la hiérarchie des magasins ne sont pas disponibles.";
            break;
        default:
            message = "Store hierarchy data is not available.";
            break;
    }
    return message;
};