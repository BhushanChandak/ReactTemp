import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  menuOpen: false,
  isLoaderVisible: false,
};

const commonSlice = createSlice({
  name: "common",
  initialState,
  reducers: {
    setMenuOpen: (state: any, action: any) => {
      state.menuOpen = action.payload;
    },
    setLoaderVisibility: (state: any, action: any) => {
      state.isLoaderVisible = action.payload;
    }
  },
});

export const {
  setMenuOpen,
  setLoaderVisibility,
} = commonSlice.actions;

export const commonReducer = commonSlice.reducer;
