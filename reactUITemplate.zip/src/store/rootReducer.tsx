//import { connectRouter } from "connected-react-router";
import { combineReducers } from "redux";
import { powerbiReducer } from "../containers/power-bi/slice";
import { usersReducer } from "../containers/user/slice";
import { commonReducer } from "./common/slice";

export default (history: any) =>
  combineReducers({
    //  router: connectRouter(history),
    users: usersReducer,
    common: commonReducer,
    power: powerbiReducer
  });
