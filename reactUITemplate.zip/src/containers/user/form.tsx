import { Button, Form, Input } from "antd";

const UserFormComponent = (props: any) => {
    const { createUser } = props;
    return (
        <Form
            autoComplete="off"
            layout="vertical"
            labelCol={{ span: 10 }}
            wrapperCol={{ span: 24 }}
            onFinish={(values) => {
                console.log({ values });
                createUser(values);
            }}
            onFinishFailed={(error) => {
                console.log({ error });
            }}
        >
            <Form.Item
                name="name"
                label="Full Name"
                rules={[
                    {
                        required: true,
                        message: "Please enter user name",
                    },
                    { whitespace: true },
                    { min: 3 },
                ]}
                hasFeedback
            >
                <Input placeholder="Enter user name" />
            </Form.Item>

            <Form.Item
                name="email"
                label="Email"
                rules={[
                    {
                        required: true,
                        message: "Please enter user email",
                    },
                    { type: "email", message: "Please enter a valid email" },
                ]}
                hasFeedback
            >
                <Input placeholder="Type user email" />
            </Form.Item>
            <Form.Item
                name="location"
                label="Location"
                rules={[
                    {
                        required: true,
                        message: "Please enter user location",
                    },
                    { whitespace: true },
                    { min: 3 },
                ]}
                hasFeedback
            >
                <Input placeholder="Enter user location" />
            </Form.Item>
            <Form.Item
                name="mobile"
                label="Mobile No"
                rules={[
                    { required: true, message: 'Please input your phone number!' },
                    { min: 10 }
                ]}
                hasFeedback
            >
                <Input type="number" placeholder="Enter user mobile number" />
            </Form.Item>

            <Form.Item wrapperCol={{ span: 24 }}>
                <Button type="primary" htmlType="submit" style={{ float: 'right' }}>
                    Add
                </Button>
            </Form.Item>
        </Form>
    )
}

export default UserFormComponent;