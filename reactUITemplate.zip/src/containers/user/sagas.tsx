import { all, call, delay, put, takeLatest } from "redux-saga/effects";
import { setLoaderVisibility } from "../../store/common/slice";
import { showToster } from "../../utils/data";
import { featchListOfUsers, postCreateUser } from "./api";
import { actionCreateUser, actionFetchUserList, actionSetUsersListSuccess } from "./slice";

export interface ResponseGenerator {
    config?: any,
    data?: any,
    headers?: any,
    request?: any,
    status?: number,
    statusText?: string
}

function* watchGetUsersList() {
    yield takeLatest(actionFetchUserList, getUsersList);
}

function* getUsersList(action: any) {
    try {
        yield put(setLoaderVisibility(true));
        const response: ResponseGenerator = yield call(featchListOfUsers);
        const responseData = response.data;
        if (responseData.length) {
            yield put(actionSetUsersListSuccess(responseData));

        }

        yield put(setLoaderVisibility(false));
    } catch (err) {
        yield put(setLoaderVisibility(false));
        // yield put(openToaster({ data: API_ERROR_MESSAGE(), success: false }));
        //yield delay(COMMON_CONSTANT.SHOW_TOSTER_TIME_INTERVEL);
        // yield put(closeToaster());
        showToster('error', 'Error while feaching data');
        console.log(err);
    }
}


function* watchPostNewUser() {
    yield takeLatest(actionCreateUser, postNewUser);
}

function* postNewUser(action: any) {
    try {
        yield put(setLoaderVisibility(true));
        const response: ResponseGenerator = yield call(postCreateUser, action.payload);
        const responseData = response.status;
        if (responseData === 201) {
            showToster('success', 'User added in list successfully');
            yield put(actionFetchUserList());
        }

        yield put(setLoaderVisibility(false));
    } catch (err) {
        yield put(setLoaderVisibility(false));
        showToster('error', 'Error while saving data');
        // yield put(openToaster({ data: API_ERROR_MESSAGE(), success: false }));
        //yield delay(COMMON_CONSTANT.SHOW_TOSTER_TIME_INTERVEL);
        // yield put(closeToaster());
        console.log(err);
    }
}

export default function* usersSaga() {
    yield all([
        watchGetUsersList(),
        watchPostNewUser()
    ]);
}