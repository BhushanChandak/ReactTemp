import { createAction, createSlice } from "@reduxjs/toolkit";
import { DataType } from ".";

export const actionFetchUserList = createAction("GET_USER_LIST_DATA");
export const actionCreateUser = createAction<DataType>("POST_NEW_USER_DATA");

const initialState = {
    usersList: {}
};

const users = createSlice({
    name: "users",
    initialState,
    reducers: {
        actionSetUsersListSuccess: (state: any, action: any) => {
            state.usersList = action.payload;
        },
    },
});

export const {
    actionSetUsersListSuccess,
} = users.actions;

export const usersReducer = users.reducer;