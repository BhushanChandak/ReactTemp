import React, { useEffect, useState } from 'react';
import { Button, Card, Col, Form, Input, Modal, Row } from 'antd';
import { useDispatch, useSelector } from 'react-redux';
import { actionCreateUser, actionFetchUserList } from './slice';
import Table, { ColumnsType } from 'antd/lib/table';
import Title from 'antd/lib/typography/Title';
import { PlusOutlined } from '@ant-design/icons';
import { showToster } from '../../utils/data';
import { tableColumnTextFilterConfig } from '../../utils/antTableSearchFilter';
import UserFormComponent from './form';


export interface DataType {
    key: React.Key;
    name: string;
    email: string;
    location: string;
    mobile: number
}

const columns: ColumnsType<DataType> = [
    {
        title: 'Name',
        dataIndex: 'name',
        sorter: (a: any, b: any) => a.name.localeCompare(b.name),
        ...tableColumnTextFilterConfig('name'),
        onFilter: (value, record) => {
            return record.name
                .toString()
                .toLowerCase()
                .includes(value.toString().toLowerCase())
        },
    },
    {
        title: 'Email',
        dataIndex: 'email',
        sorter: (a: any, b: any) => a.email.localeCompare(b.email),
        ...tableColumnTextFilterConfig('email'),
        onFilter: (value, record) => {
            return record.email
                .toString()
                .toLowerCase()
                .includes(value.toString().toLowerCase())
        },
    },
    {
        title: 'Location',
        dataIndex: 'location',
        sorter: (a: any, b: any) => a.location.localeCompare(b.location),
        ...tableColumnTextFilterConfig('location'),
        onFilter: (value, record) => {
            return record.location
                .toString()
                .toLowerCase()
                .includes(value.toString().toLowerCase())
        },
    },
    {
        title: 'Mobile',
        dataIndex: 'mobile',
        sorter: (a: any, b: any) => a.mobile - b.mobile,
        ...tableColumnTextFilterConfig('mobile'),
        onFilter: (value, record) => {
            return record.mobile
                .toString()
                .toLowerCase()
                .includes(value.toString().toLowerCase())
        },
    },
];

const UserComponent = () => {
    const dispatch = useDispatch();
    const usersList = useSelector(
        (state: any) => state.users.usersList
    );
    const [gridData, setGridData] = useState([]);
    const [isModalVisible, setIsModalVisible] = useState(false);

    //throw Error('error');

    useEffect(() => {
        dispatch(actionFetchUserList());
    }, []);

    useEffect(() => {
        if (usersList.length) {
            setGridData(usersList)
        } else {
            setGridData([]);
        }
    }, [usersList])

    const showModal = () => {
        setIsModalVisible(true);
    };

    const handleOk = () => {
        setIsModalVisible(false);
    };

    const handleCancel = () => {
        setIsModalVisible(false);
    };

    const createUser = (data: DataType) => {
        dispatch(actionCreateUser(data));
        handleCancel();
    }

    return (
        <>
            <Row justify="space-between" gutter={16} >
                <Col span={4}>
                    <Title level={4}>Users ({gridData.length})</Title>
                </Col>
                <Col span={4} style={{ textAlign: 'right' }} >
                    <Button type="primary" icon={<PlusOutlined />} onClick={showModal}>
                        Add User
                    </Button>
                </Col>
            </Row>
            <Row >
                <Col span={24}>
                    <Table
                        columns={columns}
                        dataSource={gridData}
                        pagination={{ showTotal: (total: any, range: any) => `${range[0]}-${range[1]} of ${total} items` }}
                    />
                </Col>
            </Row>
            <Modal
                title="Add User"
                width={400}
                visible={isModalVisible}
                onOk={handleOk}
                onCancel={handleCancel}
                footer={null}>
                <UserFormComponent
                    createUser={createUser} />
            </Modal>
        </>
    )
};

export default UserComponent;