export const GET_LIST_OF_USERS: string = `/api/user/list`;
export const CREATE_NEW_USER: string = `/api/user/list`;