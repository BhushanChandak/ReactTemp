import api from "../../utils/api";
import { CREATE_NEW_USER, GET_LIST_OF_USERS } from "./constants";


export const featchListOfUsers = async () => {
    const response = await api.get(`${GET_LIST_OF_USERS}`);
    return response;
};

export const postCreateUser = async (data: any) => {
    const response = await api.post(`${CREATE_NEW_USER}`, data);
    return response;
};