import React from 'react';
import { Carousel, Col, Row } from 'antd';
import Title from 'antd/lib/typography/Title';
import InlineEditComponent from './table-inline';

const contentStyle: React.CSSProperties = {
    height: '360px',
    color: '#fff',
    textAlign: 'center',
    background: '#598F86',
    fontSize: "40px"
};

const HomeComponent: React.FC = () => (
    <>
        <Row justify="space-between" gutter={16} >
            <Col span={4}>
                <Title level={4}>Home </Title>
            </Col>
        </Row>
        <InlineEditComponent></InlineEditComponent>
        <br />
        <br />
        <Carousel autoplay>
            <div>
                <h1 style={contentStyle}>1</h1>
            </div>
            <div>
                <h1 style={contentStyle}>2</h1>
            </div>
            <div>
                <h1 style={contentStyle}>3</h1>
            </div>
            <div>
                <h1 style={contentStyle}>4</h1>
            </div>
        </Carousel>
    </>

);

export default HomeComponent;