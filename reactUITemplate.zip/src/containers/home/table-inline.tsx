import { PlusCircleOutlined } from '@ant-design/icons';
import { Col, InputRef, Modal, Row, Select } from 'antd';
import { Button, Form, Input, Table } from 'antd';
import type { FormInstance } from 'antd/es/form';
import React, { useContext, useEffect, useRef, useState } from 'react';
const { Option } = Select;

interface DataType {
    key: React.Key;
    manufacture: string;
    product: string;
    jan: string;
    feb: string;
    mar: string;
    apr: string;
    may: string;
    jun: string;
    jul: string;
    aug: string;
    sep: string;
    oct: string;
    nov: string;
    dec: string;
    total: string;
}

interface Item {
    key: React.Key;
    manufacture: string;
    product: string;
    jan: string;
    feb: string;
    mar: string;
    apr: string;
    may: string;
    jun: string;
    jul: string;
    aug: string;
    sep: string;
    oct: string;
    nov: string;
    dec: string;
    total: string;
}

interface EditableRowProps {
    index: number;
}

interface EditableCellProps {
    title: React.ReactNode;
    editable: boolean;
    children: any;
    dataIndex: keyof Item;
    record: Item;
    handleSave: (record: Item) => void;
}
const InlineEditComponent: React.FC = () => {
    const [dataSource, setDataSource] = useState<DataType[]>([
        {
            key: '0',
            manufacture: 'AstraZenica AB',
            product: 'AZD 1222',
            jan: "500",
            feb: "300",
            mar: "800",
            apr: "400",
            may: "500",
            jun: "",
            jul: "",
            aug: "",
            sep: "",
            oct: "",
            nov: "",
            dec: "",
            total: "2500"
        },
        {
            key: '1',
            manufacture: "Novavax Inc",
            product: 'NVX-CoV2373/Co',
            jan: "300",
            feb: "300",
            mar: "400",
            apr: "",
            may: "",
            jun: "",
            jul: "",
            aug: "",
            sep: "",
            oct: "",
            nov: "",
            dec: "",
            total: "1000"
        }
    ]);

    const modalColumns = [{
        title: 'Funding Source Name',
        dataIndex: 'option',
    },
    {
        title: 'Quantity',
        dataIndex: 'value',
    }]

    const modalData = [{
        key: '1',
        option: 'AVAT',
        value: 200,
    },
    {
        key: '2',
        option: 'SAVI',
        value: 200,
    },
    {
        key: '3',
        option: 'Total',
        value: 400,
    }
    ]
    const EditableContext = React.createContext<FormInstance<any> | null>(null);

    const EditableRow: React.FC<EditableRowProps> = ({ index, ...props }) => {
        const [form] = Form.useForm();
        return (
            <Form form={form} component={false}>
                <EditableContext.Provider value={form}>
                    <tr {...props} />
                </EditableContext.Provider>
            </Form>
        );
    };



    const EditableCell: React.FC<EditableCellProps> = ({
        title,
        editable,
        children,
        dataIndex,
        record,
        handleSave,
        ...restProps
    }) => {
        const [editing, setEditing] = useState(false);
        const inputRef = useRef<InputRef>(null);
        const form = useContext(EditableContext)!;

        useEffect(() => {
            if (editing) {
                inputRef.current!.focus();
            }
        }, [editing]);

        const toggleEdit = () => {
            setEditing(!editing);
            form.setFieldsValue({ [dataIndex]: record[dataIndex] });
        };

        const save = async () => {
            try {
                const values = await form.validateFields();

                toggleEdit();
                handleSave({ ...record, ...values });
            } catch (errInfo) {
                console.log('Save failed:', errInfo);
            }
        };

        let childNode = children;
        if (editable) {
            childNode = editing ? (
                <>
                    <Form.Item
                        style={{ width: 70, padding: 0, margin: 0 }}
                        name={dataIndex}
                    >
                        <Input ref={inputRef} onPressEnter={save} onBlur={save} />
                    </Form.Item>

                </>
            ) : (
                <>
                    <span className="editable-cell-value-wrap" style={{ paddingRight: 24 }} onClick={toggleEdit}>
                        {children[1] == 400 ? <span className='redText'>{children}</span> : (children)}
                    </span>
                    {children[1] ? (<PlusCircleOutlined onClick={showModal} />) : null}
                </>
            );
        }

        return <td {...restProps}>{childNode}</td>;
    };

    type EditableTableProps = Parameters<typeof Table>[0];



    type ColumnTypes = Exclude<EditableTableProps['columns'], undefined>;
    const [isModalVisible, setIsModalVisible] = useState(false);

    const showModal = () => {
        setIsModalVisible(true);
    };

    const handleOk = () => {
        setIsModalVisible(false);
    };

    const handleCancel = () => {
        setIsModalVisible(false);
    };



    const defaultColumns: (ColumnTypes[number] & { editable?: boolean; dataIndex: string })[] = [
        {
            title: 'Manufacture',
            dataIndex: 'manufacture',
        },
        {
            title: 'Vaccine Name',
            dataIndex: 'product',
        },
        {
            title: 'Jan',
            dataIndex: 'jan',

        },
        {
            title: 'Feb',
            dataIndex: 'feb',
        },
        {
            title: 'Mar',
            dataIndex: 'mar',
        },
        {
            title: 'Apr',
            dataIndex: 'apr',
            editable: true,
        },
        {
            title: 'May',
            dataIndex: 'may',
            editable: true,
        },
        {
            title: 'Jun',
            dataIndex: 'jun',
            editable: true,
        },
        {
            title: 'Jul',
            dataIndex: 'jul',
        },
        {
            title: 'Aug',
            dataIndex: 'aug',
        },
        {
            title: 'Sep',
            dataIndex: 'sep',
        },
        {
            title: 'Oct',
            dataIndex: 'oct',
        },
        {
            title: 'Nov',
            dataIndex: 'nov',
        },
        {
            title: 'Dec',
            dataIndex: 'dec',
        },
        {
            title: 'Total Shipment',
            dataIndex: 'total',
        },

    ];


    const handleSave = (row: DataType) => {
        const newData = [...dataSource];
        const index = newData.findIndex(item => row.key === item.key);
        const item = newData[index];
        newData.splice(index, 1, {
            ...item,
            ...row,
        });
        setDataSource(newData);
    };

    const components = {
        body: {
            row: EditableRow,
            cell: EditableCell,
        },
    };

    const columns = defaultColumns.map(col => {
        if (!col.editable) {
            return col;
        }
        return {
            ...col,
            onCell: (record: DataType) => ({
                record,
                editable: col.editable,
                dataIndex: col.dataIndex,
                title: col.title,
                handleSave,
            }),
        };
    });

    const handleChange = (value: string) => {
        console.log(`selected ${value}`);
    };

    return (
        <div>

            <Table
                components={components}
                rowClassName={() => 'editable-row'}
                bordered
                dataSource={dataSource}
                columns={columns as ColumnTypes}
            />
            <Modal visible={isModalVisible} onOk={handleOk} onCancel={handleCancel} width={400}>
                <Row justify="space-around" gutter={16} >
                    <Col span={8} >
                        <Select defaultValue="option2" style={{ width: 120 }} onChange={handleChange}>
                            <Option value="option1">AVAT</Option>
                            <Option value="option2">SAVI</Option>
                        </Select>
                    </Col>
                    <Col span={8} >
                        <Input type="number" placeholder="Quntity" />
                    </Col>
                    <Col span={8} >
                        <Button type="primary">Add</Button>
                    </Col>
                </Row>
                <br />
                <Row>
                    <Col>
                        <Table columns={modalColumns} dataSource={modalData} pagination={false} style={{ width: 350 }} />
                    </Col>
                </Row>
            </Modal>
        </div>
    );
};

export default InlineEditComponent;