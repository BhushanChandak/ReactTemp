
import { Col, Row } from 'antd';
import Title from 'antd/lib/typography/Title';
import { PowerBIEmbed } from 'powerbi-client-react';
import { models } from 'powerbi-client'
import { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { actionFetchPowerBiReportInfo } from './slice';
import { useSelector } from 'react-redux';
import './power-bi.css'
const reportConfig = (window as any).GetReportConfig();

const getQueryParam = () => {
    var urlParams = new URLSearchParams(window.location.search);
    let filterBy = urlParams.get("filterBy");
    if (filterBy == null || filterBy == "All") {
        filterBy = "";
    }
    return filterBy;
};
const PowerBIComponent = () => {
    var reportData = {}
    const filterByParam= getQueryParam();
    const dispatch = useDispatch();
    const reportInfo = useSelector(
        (state: any) => state.power.reportInfo
    );

    useEffect(() => {
        dispatch(actionFetchPowerBiReportInfo(reportConfig.reportId))
    }, [])
    useEffect(() => {
        if (reportInfo.hasOwnProperty('reportId')) {
            reportData=reportInfo;
        }
    }, [reportInfo]);
    const predefinedFilter = {
        $schema: "http://powerbi.com/product/schema#basic",
        filterType:1,
        target: {
            table: "groceries",
            column: "Item"
        },
        operator: "In",
        values: [filterByParam]
    };    
    
    const reportLoadConfig = {
        type: 'report',   // Supported types: report, dashboard, tile, visual and qna
        id: reportInfo.reportId,
        embedUrl: reportInfo.embedUrl,
        accessToken: reportInfo.accessToken,
        tokenType: models.TokenType.Embed,
        permissions: models.Permissions.All,
        settings: {
            filterPaneEnabled: false,
            navContentPaneEnabled: false,            
            background: models.BackgroundType.Transparent
        },        
        filters: filterByParam == "" ? [] : [predefinedFilter]
    }
    const filterPage = (event:any)  => {
        var url = window.location.origin + window.location.pathname;
        (window as any).location = url + "?filterBy=" + event.target.value ;
    }
    return (        
        <>
            <Row justify="space-between" gutter={16} >
                <Col span={4}>
                    <Title level={4}>Power BI</Title>
                </Col>
                <Col span={4}>
                    <select value={filterByParam} onChange={filterPage}>
                        <option value="All">Show All</option>
                        <option>baby cosmetics</option>
                        <option>baby food</option>
                        <option>bags</option>
                        <option>baking powder</option>
                        <option>bathroom cleaner</option>
                        <option>berries</option>
                        <option>beverages</option>
                        <option>bottled beer</option>
                        <option>bottled water</option>
                        <option>brandy</option>
                        <option>brown bread</option>
                        <option>butter</option>
                        <option>butter milk</option>
                        <option>cake bar</option>
                    </select>
                </Col>
            </Row>
            <Row >
                <Col span={24}>
                    <PowerBIEmbed

                        embedConfig={reportLoadConfig}
                        eventHandlers={
                            new Map([
                                ['loaded', function () { console.log('Report loaded'); }],
                                ['rendered', function () { console.log('Report rendered'); }],
                                ['error', function (event: any) { console.log(event.detail); }]
                            ])
                        }
                        
                        cssClassName={"embed-power-bi-style"}

                        getEmbeddedComponent={(embeddedReport: any) => {
                            (window as any).report = embeddedReport;
                        }}
                    />
                </Col>
            </Row>

        </>
    )
};

export default PowerBIComponent;