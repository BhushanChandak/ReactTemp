import { all, call, delay, put, takeLatest } from "redux-saga/effects";
import { setLoaderVisibility } from "../../store/common/slice";
import { showToster } from "../../utils/data";
import { fetchPowerBiInfo } from "./api";
import { actionFetchPowerBiReportInfo, actionFetchPowerBiReportInfoSuccess } from "./slice";

export interface ResponseGenerator {
    config?: any,
    data?: any,
    headers?: any,
    request?: any,
    status?: number,
    statusText?: string
}

function* watchGetPowerBiReportInfo() {
    yield takeLatest(actionFetchPowerBiReportInfo, getPowerBiReportInfo);
}

function* getPowerBiReportInfo(action: any) {
    try {
        yield put(setLoaderVisibility(true));
        const response: ResponseGenerator = yield call(fetchPowerBiInfo, action.payload);

        if (response) {
            yield put(actionFetchPowerBiReportInfoSuccess(response.data));

        }

        yield put(setLoaderVisibility(false));
    } catch (err) {
        yield put(setLoaderVisibility(false));
        // yield put(openToaster({ data: API_ERROR_MESSAGE(), success: false }));
        //yield delay(COMMON_CONSTANT.SHOW_TOSTER_TIME_INTERVEL);
        // yield put(closeToaster());
        showToster('error', 'Error while feaching data');
        console.log(err);
    }
}

export default function* powerBiSaga() {
    yield all([
        watchGetPowerBiReportInfo(),
    ]);
}