import api from "../../utils/api";
import { GET_POWER_BI_INFO } from "./constants";


export const fetchPowerBiInfo = async (reportId:any) => {
    const response = await api.get(`${GET_POWER_BI_INFO}?reportId=${reportId}`);
    return response;
};
