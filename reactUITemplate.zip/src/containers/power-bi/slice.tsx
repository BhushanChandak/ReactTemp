import { createAction, createSlice } from "@reduxjs/toolkit";

export const actionFetchPowerBiReportInfo = createAction<string | undefined>("GET_POWER_BI_REPORT_INFO");
const initialState = {
    reportInfo: {}
};

const powerbi = createSlice({
    name: "powerbi",
    initialState,
    reducers: {
        actionFetchPowerBiReportInfoSuccess: (state: any, action: any) => {
            state.reportInfo = action.payload;
        },
    },
});

export const {
    actionFetchPowerBiReportInfoSuccess,
} = powerbi.actions;

export const powerbiReducer = powerbi.reducer;