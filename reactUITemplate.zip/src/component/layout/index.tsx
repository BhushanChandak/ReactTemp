import React, { useState } from 'react';
import { Layout, Menu, Breadcrumb, Dropdown, Space, Avatar, Row, Col, Spin } from 'antd';
import {
    DesktopOutlined,
    PieChartOutlined,
    FileOutlined,
    TeamOutlined,
    UserOutlined,
    DownOutlined,
    LoadingOutlined
} from '@ant-design/icons';
import type { MenuProps } from 'antd';
import './index.css'
import HomeComponent from '../../containers/home';
import { HOME, POWER_BI, USER } from '../../constants/api';
import UserComponent from '../../containers/user';
import { Route, Routes, useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import Logo from "../../images/logo.png";
import PowerBIComponent from '../../containers/power-bi';


const { Header, Content, Footer, Sider } = Layout;

type MenuItem = Required<MenuProps>['items'][number];
const menu = (
    <Menu
        items={[
            {
                label: 'Admin',
                key: '0',
            },
            {
                label: 'UNICEF',
                key: '1',
            },
            {
                type: 'divider',
            },
            {
                label: 'Logout',
                key: '3',
            },
        ]}
    />
);

function getItem(
    label: React.ReactNode,
    key: React.Key,
    icon?: React.ReactNode,
    children?: MenuItem[],
): MenuItem {
    return {
        key,
        icon,
        children,
        label,
    } as MenuItem;
}

const items: MenuItem[] = [
    getItem('Home', HOME, <PieChartOutlined />),
    getItem('User', USER, <DesktopOutlined />),
    getItem('Power BI', POWER_BI, <FileOutlined />),
    getItem('User', 'sub1', <UserOutlined />, [
        getItem('Tom', '3'),
        getItem('Bill', '4'),
        getItem('Alex', '5'),
    ]),
    getItem('Team', 'sub2', <TeamOutlined />, [getItem('Team 1', '6'), getItem('Team 2', '8')]),

];

const antIcon = <LoadingOutlined style={{ fontSize: 34 }} spin />;

const LayoutComponent: React.FC = () => {
    const navigate = useNavigate();
    const [collapsed, setCollapsed] = useState(true);
    const [currentPath, setCurrentPath] = useState(window.location.pathname);
    const isLoaderVisible = useSelector(
        (state: any) => state.common.isLoaderVisible
    );

    const handelMenuClick = (e: any) => {
        setCurrentPath(e.key);
        navigate(e.key)
    }

    return (
        <Layout style={{ minHeight: '100vh' }}>
            {isLoaderVisible ? (
                <Spin indicator={antIcon} className="pageLoader" />
            ) : (null)}
            <Header className="site-layout-background" style={{ padding: 0, background: "1CABE2" }} >
                <Row justify="space-between">
                    <Col >
                        <div className="logo">
                            <img src={Logo} />
                        </div>
                    </Col>
                    <Col style={{ textAlign: 'right', margin: "0 24px" }}>
                        <Dropdown overlay={menu} trigger={['click']} arrow>
                            <a onClick={e => e.preventDefault()}>
                                <Space>
                                    <Avatar icon={<UserOutlined />} />
                                    Bhushan Chandak
                                    <DownOutlined />
                                </Space>
                            </a>
                        </Dropdown>
                    </Col>
                </Row>
            </Header>
            <Layout className="site-layout">
                <Sider collapsible collapsed={collapsed} onCollapse={value => setCollapsed(value)}>
                    <Menu theme="light" defaultSelectedKeys={[HOME]} selectedKeys={[currentPath]} mode="inline" items={items} onClick={handelMenuClick} />
                </Sider>
                <Content style={{ margin: '8px 16px' }}>
                    <div className="site-layout-background" style={{ minHeight: 360 }}>
                        <Routes>
                            <Route path="/" element={<HomeComponent />} />
                            <Route path={HOME} element={<HomeComponent />} />
                            <Route path={USER} element={<UserComponent />} />
                            <Route path={POWER_BI} element={<PowerBIComponent />} />
                        </Routes>
                    </div>
                </Content>
            </Layout>
            <Footer style={{ textAlign: 'center' }}>© Copyright of e-Zest</Footer>
        </Layout>
    );
};

export default LayoutComponent;