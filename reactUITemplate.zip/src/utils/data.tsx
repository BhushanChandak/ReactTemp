import { message } from "antd";


export const showToster = (msgType: string, msg: string) => {
    // const languageSelected = localStorage.getItem("language");
    let toster;
    switch (msgType) {
        case "success":
            toster = message.success(msg);
            break;

        case "error":
            toster = message.error(msg);
            break;

        case "warning":
            toster = message.warning(msg);
            break;

    }
    return toster;
};