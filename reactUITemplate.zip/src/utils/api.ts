import axios from "axios";
import { BASE_PATH } from "../constants/api";

const api = axios.create({
    baseURL: BASE_PATH,
});

api.interceptors.request.use(
    (config: any) => {
        // config.headers.Authorization =
        //     "Bearer " + localStorage.getItem(AUTH_TOKEN);
        // config.headers.Language = localStorage.getItem("language");
        config.headers["Content-Type"] = "application/json";
        return config;
    },
    (err) => {
        console.log(err);
        Promise.reject(err);
    }
);

export default api;
