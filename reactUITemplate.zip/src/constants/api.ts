export const BASE_PATH: string = 'https://629703708d77ad6f75f8e4e8.mockapi.io';
export const HOME: string = "/home";
export const USER: string = "/user";
export const POWER_BI: string = '/power-bi'